/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gestiondocumentalbase;

import gestiondocumentalbase.database.Conexion;
import gestiondocumentalbase.jdbc.DocumentoDao;
import java.sql.Connection;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author edwar
 */
public class GestionDocumentalBase {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {       
        ConsolaGestionArchivos con = new ConsolaGestionArchivos();
        con.setVisible(true);
        
    }
    
}
