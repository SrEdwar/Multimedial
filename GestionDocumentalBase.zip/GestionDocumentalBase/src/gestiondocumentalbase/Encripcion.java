package gestiondocumentalbase;

import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * @author duvan.acevedo
 */
public class Encripcion {

    public static void main(String[] args) {

        Encriptador encriptador = new Encriptador();
        try {
            System.out.println(" ## Encripción con método 1 ## ");
            String encriptadoMet1 = encriptador.encript("Texto");
            String otroEncriptadoMet1 = encriptador.encript("Texto, el cuál es más extenso");
            System.out.println(encriptadoMet1);
            System.out.println(otroEncriptadoMet1);

            System.out.println(" ## Encripción con método 2 ## ");
            String encriptadoMet2 = encriptador.encriptar("Texto");
            String otroEncriptadoMet2 = encriptador.encriptar("Texto, el cuál es más extenso");
            System.out.println(encriptadoMet2);
            System.out.println(otroEncriptadoMet2);

            System.out.println(" ## Desencripción con método 1 ## ");
            System.out.println(encriptador.decrypt(encriptadoMet1));
            System.out.println(encriptador.decrypt(otroEncriptadoMet1));
            System.out.println(" ## Desencripción con método 2 ## ");
            System.out.println(encriptador.desencriptar(encriptadoMet2));
            System.out.println(encriptador.desencriptar(otroEncriptadoMet2));
        } catch (Exception ex) {
            Logger.getLogger(Encripcion.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

}
