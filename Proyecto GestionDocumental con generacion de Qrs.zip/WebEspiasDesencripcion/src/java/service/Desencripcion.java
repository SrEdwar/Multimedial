/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package service;

import encripcion.Encriptador;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;

/**
 *
 * @author edwar
 */
@WebService(serviceName = "desencripcion")
public class Desencripcion {

    /**
     * This is a sample web service operation
     */
    @WebMethod(operationName = "desencripcion")
    public String desencripcion(@WebParam(name = "codigoEncriptado") String codigoEncriptado) {
        Encriptador encriptador = new Encriptador();
       
        
        try {
            return "Resultado: "+encriptador.decrypt(codigoEncriptado);
        } catch (Exception ex) {
            Logger.getLogger(Desencripcion.class.getName()).log(Level.SEVERE, null, ex);
        }
        return "Error al desencriptar";
    }
}
