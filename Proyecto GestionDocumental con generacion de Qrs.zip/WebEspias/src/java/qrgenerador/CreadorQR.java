/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package qrgenerador;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.Writer;
import com.google.zxing.WriterException;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.QRCodeWriter;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.UUID;
import javax.imageio.ImageIO;



/**
 *
 * @author edwar
 */
public class CreadorQR {
    
    public  void crearQR(String contenido,int ancho,int altura,String nombre) throws WriterException, IOException{
        
      
        
        //Se crea el compilado del codigo QR
        Writer escritor = new QRCodeWriter();
        BitMatrix matrix = escritor.encode(contenido, BarcodeFormat.QR_CODE, ancho, altura);
        BufferedImage image = new BufferedImage(ancho, altura, BufferedImage.TYPE_INT_RGB);
        
    
        
        
        for(int y=0; y <altura; y++){
            for(int x=0;x<ancho;x++){
                int grayValue = (matrix.get(x,y) ? 0:1)& 0xff;
                image.setRGB(x,y, (grayValue == 0 ? 0 : 0xFFFFFF));
            }
        }
        
        
        guardarQR(image,nombre);
 
 
        
        
        
    }
    
    public  void crearQRGraphics(String contenido,int ancho,int altura,String nombre) throws WriterException, IOException{
        
      
        
        //Se crea el compilado del codigo QR
        Writer escritor = new QRCodeWriter();
        BitMatrix matrix = escritor.encode(contenido, BarcodeFormat.QR_CODE, ancho, altura);
        BufferedImage image = new BufferedImage(ancho, altura, BufferedImage.TYPE_INT_RGB);
        
        Graphics graphics = (Graphics2D)image.getGraphics();
        graphics.setColor(Color.white);
        graphics.fill3DRect(0, 0, ancho, altura, true);
        graphics.setColor(Color.black);
        
       
        for(int y=0; y <altura; y++){
            for(int x=0;x<ancho;x++){
                if(matrix.get(y,x)){
                    graphics.fillRect(y, x, 1, 1);
                }
            }
        }
        guardarQR(image, nombre);
        
        
 
 
        
        
        
    }
    private void guardarQR(BufferedImage image,String nombreArchivo) throws IOException{
        UUID  uuid = UUID.randomUUID();
        String ruta = "Z://CodigosQrs/";
        String extension = "png";
        File grFile = new File(nombreArchivo);
        ImageIO.write(image,extension, grFile);
        
    }
    
}
