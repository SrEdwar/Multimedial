/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gestiondocumentalbase.dto;

import gestiondocumentalbase.Encriptador;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author edwar
 */
public class Documento {
    Encriptador encriptador = new Encriptador();
    private int idDocumento;
    private String ruta;

    public int getIdDocumento() {
        return idDocumento;
    }

    public void setIdDocumento(int idDocumento) {
        this.idDocumento = idDocumento;
    }

    public String getRuta() {
        return ruta;
    }

    public void setRuta(String ruta) {
        try {
            String encrip = encriptador.encript(ruta);
            this.ruta = encrip;
        } catch (Exception ex) {
            System.out.println("Error en la encripcion");
        }
        
    }
    
    
}
