/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gestiondocumentalbase.jdbc;



import gestiondocumentalbase.dto.Documento;
import java.sql.*;


/**
 *
 * @author edwar
 */
public class DocumentoDao {
  
    private final String tabla = "DOCUMENTO";
    public void guardar (Connection conexion, Documento documento)throws SQLException, Exception{
        try {
            
            PreparedStatement consulta;
            consulta = conexion.prepareStatement("INSERT INTO "+ tabla +
                    "(ID_DOCUMENTO,RUTA) values(?,?)");
            
            consulta.setInt(1, documento.getIdDocumento());
            consulta.setString(2,documento.getRuta());
            
            consulta.executeUpdate();
        } catch (SQLException ex) {
           throw new SQLException(ex) ;
        } 
        
        
    }
    public Documento consultaPorId(Connection conexion,int id)throws SQLException, Exception{
        Documento documento = null;
        try {
            PreparedStatement consulta;
            consulta = conexion.prepareStatement("SELECT ID_DOCUMENTO, RUTA FROM "
                    + tabla + " WHERE ID_DOCUMENTO = ?");
                    
            consulta.setInt(1, id);
            ResultSet resultado = consulta.executeQuery();
            if(resultado.next()){
                
                documento = new Documento();
                documento.setIdDocumento(resultado.getInt("ID_DOCUMENTO"));
                documento.setRuta(resultado.getString("RUTA"));
            }
           
        } catch (SQLException ex) {
           throw new SQLException(ex) ;
        } 
        return documento;
    }
    
    public int consultarUltimoId(Connection conexion)throws SQLException{
        int ultimoId = 0;
        try {
            PreparedStatement consulta;
            consulta = conexion.prepareStatement("SELECT MAX(ID_DOCUMENTO) AS ID_DOCUMENTO FROM "
                    + tabla);
                    
            
            
            ResultSet resultado = consulta.executeQuery();
            if(resultado.next()){
                ultimoId = resultado.getInt("ID_DOCUMENTO");
            }
           
        } catch (SQLException ex) {
           throw new SQLException(ex) ;
        } 
        return ultimoId;
    }

    
}
