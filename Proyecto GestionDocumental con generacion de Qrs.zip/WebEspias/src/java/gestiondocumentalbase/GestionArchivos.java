/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gestiondocumentalbase;


import gestiondocumentalbase.database.Conexion;
import gestiondocumentalbase.dto.Documento;
import gestiondocumentalbase.jdbc.DocumentoDao;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.sql.Connection;
import java.util.Calendar;
import java.util.logging.Level;
import java.util.logging.Logger;
import qrgenerador.CreadorQR;

/**
 *
 * @author edwar
 */
public class GestionArchivos {
    
    
    public void guardarArchivoPdf (File archivoParam) throws Exception{
        
        DocumentoDao documentoDao = new DocumentoDao();
        Connection conexion = null;
        try {
            
            conexion = Conexion.obtener();
        } catch (Exception ex) {
            Logger.getLogger(GestionArchivos.class.getName()).log(Level.SEVERE, null, ex);
            System.err.println("Error al conectar a la BD");
        }
        
        
        Calendar fecha = Calendar.getInstance();
        int anho = fecha.get(Calendar.YEAR);
        int mes = fecha.get(Calendar.MONTH)+1;
        int dia = fecha.get(Calendar.DAY_OF_MONTH);
        
        String ruta = "Z://ArchivosDocumentalesBaseEspias/"+anho+"/"+mes+"/"+dia+"/"+"pdf"+"/";
        String rutaQr = "Z://CodigosQrs/";
        
        File directorio = new File(ruta);
        if (!directorio.exists()){
            if(directorio.mkdirs()){
                System.out.println("Las carpetas fueron creadas");
            }else{
                System.out.println("Las carpetas no fueron creadas");
            }
        }else{
            System.out.println("Las carpetas ya estaban creadas");
        }
        
        String ruta2 = "Z://CodigosQrs/";
        
        File directorio2 = new File(ruta2);
        
        if (!directorio2.exists()){
            if(directorio2.mkdirs()){
                System.out.println("Las carpetas fueron creadas");
            }else{
                System.out.println("Las carpetas no fueron creadas");
            }
        }else{
            System.out.println("Las carpetas ya estaban creadas");
        }
        
        int ultimoId = documentoDao.consultarUltimoId(conexion);
        int idDocumento = ultimoId + 1;
        String rutaArchivoQr = rutaQr +anho+mes+dia+"_"+idDocumento+".png";
        String rutaArchivo = ruta + anho+mes+dia+"_"+idDocumento + ".pdf";
     
        
        File nuevoArchivo = new File(rutaArchivo);
        BufferedInputStream in = new BufferedInputStream(new FileInputStream(archivoParam));
        BufferedOutputStream out = new BufferedOutputStream(new FileOutputStream(rutaArchivo));
        byte[] bytes = new byte[1024];
        int len = 0;
        while ((len = in.read(bytes)) > 0) {
            out.write(bytes, 0, len);
        }
        out.flush();
        out.close();
        
      
        Documento documento = new Documento();
        documento.setIdDocumento(idDocumento);
        System.out.println(rutaArchivo);
        documento.setRuta(rutaArchivo);
        documentoDao.guardar(conexion, documento);
        System.out.println("Archivo guardado exitosamente");
        
        CreadorQR creador = new CreadorQR();
        System.out.println(documento.getRuta());
        creador.crearQR(documento.getRuta(), 300, 300,rutaArchivoQr);
      
        
        
        
        
        
        
        
        
    }
    
        public void guardarArchivoTxt (File archivoParam) throws Exception{
        
        DocumentoDao documentoDao = new DocumentoDao();
        Connection conexion = null;
        try {
            
            conexion = Conexion.obtener();
        } catch (Exception ex) {
            Logger.getLogger(GestionArchivos.class.getName()).log(Level.SEVERE, null, ex);
            System.err.println("Error al conectar a la BD");
        }
        
        
        Calendar fecha = Calendar.getInstance();
        int anho = fecha.get(Calendar.YEAR);
        int mes = fecha.get(Calendar.MONTH)+1;
        int dia = fecha.get(Calendar.DAY_OF_MONTH);
        String ruta = "Z://ArchivosDocumentalesBaseEspias/"+anho+"/"+mes+"/"+dia+"/"+"txt"+"/";
        
        File directorio = new File(ruta);
        if (!directorio.exists()){
            if(directorio.mkdirs()){
                System.out.println("Las carpetas fueron creadas");
            }else{
                System.out.println("Las carpetas no fueron creadas");
            }
        }else{
            System.out.println("Las carpetas ya estaban creadas");
        }
        
        int ultimoId = documentoDao.consultarUltimoId(conexion);
        int idDocumento = ultimoId + 1;
        String rutaArchivo = ruta + anho+mes+dia+"_"+idDocumento + ".txt";
        
        File nuevoArchivo = new File(rutaArchivo);
        BufferedInputStream in = new BufferedInputStream(new FileInputStream(archivoParam));
        BufferedOutputStream out = new BufferedOutputStream(new FileOutputStream(rutaArchivo));
        byte[] bytes = new byte[858993459];
        int len = 0;
        while ((len = in.read(bytes)) > 0) {
            out.write(bytes, 0, len);
        }
        out.flush();
        out.close();
        

        Documento documento = new Documento();
        documento.setIdDocumento(idDocumento);
        documento.setRuta(rutaArchivo);
        documentoDao.guardar(conexion, documento);
        System.out.println("Archivo guardado exitosamente");
    }
    
}
