/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package service;

import gestiondocumentalbase.GestionArchivos;
import java.io.File;
import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;

/**
 *
 * @author edwar
 */
@WebService(serviceName = "gestionDocumental")
public class gestionDocumental {

    /**
     * This is a sample web service operation
     */
    @WebMethod(operationName = "cargarUrl")
    public String cargarUrl(@WebParam(name = "url") String url) {
        File archivo = new File (url);
        GestionArchivos ga = new GestionArchivos();
        try {
                ga.guardarArchivoPdf(archivo);
            } catch (Exception ex) {
                return "Error al realizar la operacion: "+ex.getMessage()+ex.getCause();
            } 
        
        return "Archivo guardado exitosamente: Ruta de Codigos Qrs en: Z:\\CodigosQrs";
    }
}
