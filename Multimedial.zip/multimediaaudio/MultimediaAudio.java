/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package multimediaaudio;




/**
 *
 * @author edwar
 */
public class MultimediaAudio {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws Exception {
        
        
         ConsoladeReproducion f = new ConsoladeReproducion();
         f.setVisible (true);
        



        
        
        
        
        
        
        
//       Connection conexion = null;
//        try{
//            String nombreCancion = "hills.mp3";
//            conexion = Conexion.obtener();
//            Conexion.obtener();
////            Reproductor repro = new Reproductor();
////            //Cargar la cancion en un File
////            File archivoCancion = new File(repro.getUrlMp3(nombreCancion).toURI());
////            //Cargar el file en memoria por inputStream
////            FileInputStream input = new FileInputStream(archivoCancion);
////            //Creamos el arrya de bytes con tamanio de la cancion
////            byte[] bytesCancion = new byte[(int)archivoCancion.length()];
////            //Escribir el archivo en memoria (stream) a bytes
////            input.read(bytesCancion);
////            
////            Cancion cancion = new Cancion();
////            cancion.setNombre(nombreCancion);
////            cancion.setArchivo(bytesCancion);
////            
////            CancionlDao  multimedialDao = new CancionlDao();
////            multimedialDao.guardar(conexion, cancion);
//            
//            
//           
//        }catch (Exception ex){
//            System.out.println("Error al conectar a la base de datos");
//            System.out.println(ex.getMessage());
//        }
        
//        ParametroDao parametroDao = new ParametroDao();
//        
//        Parametro param = parametroDao.consultaPorId(conexion, 1);
//        System.out.println(param.getId());
//        System.out.println(param.getNombre());
//        System.out.println(param.getValor());
//  
//        CancionlDao multimedialDao = new CancionlDao();
//        Cancion cancion =  multimedialDao.consultaPorId(conexion, 1);
//        
//        System.out.println(cancion.getIdCacion());
//        System.out.println(cancion.getNombre());
//        
//        File archivoCancion = new File ("hills.mp3");
//        OutputStream output = new FileOutputStream(archivoCancion);
//        output.write(cancion.getArchivo());
//        
        
//        
//        Reproductor repro = new Reproductor();
//        repro.abrirCancion(archivoCancion);
//        repro.reproducir();
        
    }
    
}
