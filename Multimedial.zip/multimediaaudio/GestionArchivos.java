/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package multimediaaudio;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.sql.Connection;
import javax.swing.JOptionPane;
import multimedialdata.dto.Cancion;
import multimedialdata.dto.Parametro;
import multimedialdata.jdbc.CancionlDao;
import multimedialdata.jdbc.ParametroDao;

/**
 *
 * @author edwar
 */
public class GestionArchivos {
    
    public void guardarArchivos(File archivoGuardar) throws Exception{
        Connection conexion = null;
        try{
            
           conexion = Conexion.obtener();
     
        }catch (Exception ex){
            System.err.println("Error al conectar a la base de datos");
            System.err.println(ex.getMessage());
        }
        
        ParametroDao parametroDao = new ParametroDao();
        
        //Consulta el parametro de la ruta donde se deben guardar los archivos
        Parametro param = parametroDao.consultaPorId(conexion,1);
        
        System.out.println("Ruta parametrizada de los archivos: "+param.getValor());  
        
        //Guardar ruta  con la ruta parametrizada   
        File carpeta = new File(param.getValor());
        if (!carpeta.exists()){
            if(carpeta.mkdirs()){
                System.out.println("Carpeta creada");
            }else{
                System.err.println("Error creando carpeta, verifique los permisos");
            }
        }else{
            System.out.println("La ruta ya estaba creada");
        }   
        
        String rutaCompleta = param.getValor()+"/"+ archivoGuardar.getName();
        File archivo = new File(rutaCompleta);
        
        
        FileInputStream input = new FileInputStream(archivoGuardar);
        FileOutputStream output = new FileOutputStream(archivo);
        
        byte[] temp = new byte[10024];
        int byteLeido;
        while((byteLeido = input.read(temp)) >0){
            output.write(temp, 0, byteLeido);
            
        
        }
        input.close();
        output.close();
        
        BufferedWriter bw;
       
        bw = new BufferedWriter(new FileWriter(archivo));
        System.out.println("El archivo fue guardado en disco");
        
        
         //Guardar el registro en base de datos
         CancionlDao cancionDao = new CancionlDao();
         Cancion cancion = new Cancion(archivoGuardar.getName(),rutaCompleta);
         cancionDao.guardar(conexion, cancion);
         
         JOptionPane.showMessageDialog(null,"Guardaste un archivo en el sistema");
      
        
    }
    
    public File recuperarArchivo(int idCancion) throws Exception{
        Connection conexion = null;
        try{
            
            conexion = Conexion.obtener();
     
        }catch (Exception ex){
            System.out.println("Error al conectar a la base de datos");
            System.out.println(ex.getMessage());
        }
        CancionlDao cancionDao = new CancionlDao();
        Cancion cancion = cancionDao.consultaPorId(conexion,idCancion);
        
        File archivo = new File(cancion.getRuta());
     
        
        
        return archivo;
        
        
    }
    
}
