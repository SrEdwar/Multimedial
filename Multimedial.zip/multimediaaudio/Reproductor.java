/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package multimediaaudio;

import java.io.File;
import java.net.URL;


import java.util.logging.Level;
import java.util.logging.Logger;
import javazoom.jlgui.basicplayer.BasicPlayer;
import javazoom.jlgui.basicplayer.BasicPlayerException;

/**
 *
 * @author edwar
 */
public class Reproductor  {
    private BasicPlayer player = new BasicPlayer();
    private String cancion;

    public String getCancion() {
        return cancion;
    }
    
    public void reproducir() throws BasicPlayerException{
        player.play(); 
}
    public void parar() throws BasicPlayerException{
        player.stop();
    }
    public void pausar() throws BasicPlayerException{
        player.pause();
    }
    public void reanudar() throws BasicPlayerException{
        player.resume();
    }
    public void abrirCacion(String nombreCancion) throws BasicPlayerException{
        this.cancion = nombreCancion;
        URL urlCacion = getClass().getResource("/recursos/"+nombreCancion);
        player.open(urlCacion);
        
    }
    public void volument(double metodo){
        try {
            player.setGain((double)metodo);
          
            
        } catch (BasicPlayerException ex) {
            Logger.getLogger(Reproductor.class.getName()).log(Level.SEVERE, null, ex);
        }
         
    }
    public void altavoz(double metodo){
        try {
            player.setPan((double)metodo);
            
            
        } catch (BasicPlayerException ex) {
            Logger.getLogger(Reproductor.class.getName()).log(Level.SEVERE, null, ex);
        }
         
    }
    public URL getUrlMp3(String nombre) {
        return getClass().getResource("/recursos/" + nombre);
    }

    public void abrirCancion(File archivo) throws Exception {
        player.open(archivo);
       
    }

  
        
    
}
