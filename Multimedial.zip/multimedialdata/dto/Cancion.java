/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package multimedialdata.dto;

/**
 *
 * @author edwar
 */
public class Cancion {
    private Integer idCacion;
    private String nombre;
    private String ruta;
    
    public Cancion(){
        
    }
    
    public Cancion(int id,String nombre,String ruta){
        this.idCacion = id;
        this.nombre = nombre;
        this.ruta = ruta;
    }
    
    public Cancion(String nombre,String ruta){
      
        this.nombre = nombre;
        this.ruta = ruta;
    }

    

    public Integer getIdCacion() {
        return idCacion;
    }

    public void setIdCacion(Integer idCacion) {
        this.idCacion = idCacion;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getRuta() {
        return ruta;
    }

    public void setRuta(String ruta) {
        this.ruta = ruta;
    }

  
    
    
}
