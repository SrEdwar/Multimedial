/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package multimedialdata.jdbc;

import java.sql.*;
import multimedialdata.dto.Parametro;

/**
 *
 * @author edwar
 */
public class ParametroDao {
    private final String tabla = "PARAMETRO";
    public void guardar (Connection conexion, Parametro param)throws SQLException{
        try {
            PreparedStatement consulta;
            consulta = conexion.prepareStatement("INSERT INTO "+ tabla +
                    "(NOMBRE,VALOR) values(?,?)");
            consulta.setString(1, param.getNombre());
            consulta.setString(2,param.getValor());
            consulta.executeUpdate();
        } catch (SQLException ex) {
           throw new SQLException(ex) ;
        } 
        
        
    }
    public Parametro consultaPorId(Connection conexion,int id)throws SQLException{
        Parametro parametro = null;
        try {
            PreparedStatement consulta;
            consulta = conexion.prepareStatement("SELECT ID, NOMBRE, VALOR FROM "
                    + tabla + " WHERE ID = ? ");
                    
            consulta.setInt(1, id);
            ResultSet resultado = consulta.executeQuery();
            if(resultado.next()){
                parametro = new Parametro();
                parametro.setId(resultado.getInt("ID"));
                parametro.setNombre(resultado.getString("NOMBRE"));
                parametro.setValor(resultado.getString("VALOR"));
            }
           
        } catch (SQLException ex) {
           throw new SQLException(ex) ;
        } 
        return parametro;
    }
    
}
