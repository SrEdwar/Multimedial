/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package multimedialdata.jdbc;

import java.sql.*;
import multimedialdata.dto.Cancion;

/**
 *
 * @author edwar
 */
public class CancionlDao {
    private final String tabla = "CANCION";
    public void guardar (Connection conexion, Cancion cancion)throws SQLException{
        try {
            PreparedStatement consulta;
            consulta = conexion.prepareStatement("INSERT INTO "+ tabla +
                    "(NOMBRE,RUTA) values(?,?)");
            consulta.setString(1, cancion.getNombre());
            consulta.setString(2,cancion.getRuta());
            consulta.executeUpdate();
        } catch (SQLException ex) {
           throw new SQLException(ex) ;
        } 
        
        
    }
    public Cancion consultaPorId(Connection conexion,int id)throws SQLException{
        Cancion cancion = null;
        try {
            PreparedStatement consulta;
            consulta = conexion.prepareStatement("SELECT ID_CANCION, NOMBRE, RUTA FROM "
                    + tabla + " WHERE ID_CANCION = ?");
                    
            consulta.setInt(1, id);
            ResultSet resultado = consulta.executeQuery();
            if(resultado.next()){
                cancion = new Cancion();
                cancion.setIdCacion(resultado.getInt("ID_CANCION"));
                cancion.setNombre(resultado.getString("NOMBRE"));
                cancion.setRuta(resultado.getString("RUTA"));
            }
           
        } catch (SQLException ex) {
           throw new SQLException(ex) ;
        } 
        return cancion;
    }
    
}
